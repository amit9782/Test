﻿using System;
using System.Collections.Generic;
using System.Linq;
using BuyHQ.Core.Domain;

namespace BuyHQ.Data.MongoDb.Util
{
    public static class CategoryUtil
    {
        public static CategoryRepository repository = new CategoryRepository("buyhq");

        public static string GetBreadCrumb(Category category){
            var names = new List<string>();
            names.Add(category.Name);

            if(category.ParentCategoryId != null){
                Category cat = category;
                while (cat.ParentCategoryId != null)
                {
                    cat = repository.GetOne(x => x.Id == cat.ParentCategoryId);
                    names.Add(cat.Name);
                }
            }

            return string.Join(" > ", names.Select(x => x));
        }
    }
}
