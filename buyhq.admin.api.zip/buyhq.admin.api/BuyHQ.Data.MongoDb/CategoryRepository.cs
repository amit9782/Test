﻿using BornsToCode.Common.Data;
using BornsToCode.Common.Mongo;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using BuyHQ.Core.Util;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BuyHQ.Data.MongoDb
{
    public class CategoryRepository : MongoRepositoryBase<Category>, ICategoryRepository
    {
        public CategoryRepository(string dbName) : base(dbName) { }
        public CategoryRepository(string connectionString, string dbName) : base(connectionString, dbName) { }

        public override Category Save(Category category)
        {
            category.Path = category.BuildBreadcrumb(this);
            return base.Save(category);
        }

        public override Task<Category> SaveAsync(Category category)
        {
            category.Path = category.BuildBreadcrumb(this);
            return base.SaveAsync(category);
        }

        public IList<Category> FindManyById(List<Guid> ids)
        {
            // here comes the "$in" query
            var filter = Builders<Category>.Filter.In(c => c.Id, ids);

            // sync
            return collection.Find(filter).ToList();
        }
    }
}
