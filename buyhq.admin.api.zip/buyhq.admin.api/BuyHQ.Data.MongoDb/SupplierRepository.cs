﻿using System;
using System.Collections.Generic;
using System.Linq;
using BornsToCode.Common.Data;
using BornsToCode.Common.Extensions.String;
using BornsToCode.Common.Mongo;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using MongoDB.Driver;

namespace BuyHQ.Data.MongoDb
{
    public class SupplierRepository : MongoRepositoryBase<Supplier>, ISupplierRepository
    {

        public SupplierRepository(string dbName) : base(dbName) {
           
        }
        public SupplierRepository(string connectionString, string dbName) : base(connectionString, dbName) {
           
        }

        //public IList<Warehouse> GetWarehouses(Guid supplierId)
        //{
        //    throw new NotImplementedException();
        //}

        public Warehouse SaveWarehouse(Guid supplierId, Warehouse warehouse)
        {
            UpdateDefinition<Supplier> update;
            FilterDefinition<Supplier> filter;

            if (warehouse.Id != null && warehouse.Id != Guid.Empty)
            {
                filter = Builders<Supplier>.Filter.And(
                    Builders<Supplier>.Filter.Eq(x => x.Id, supplierId),
                    Builders<Supplier>.Filter.ElemMatch(x=> x.Warehouses, w=> w.Id.Equals(warehouse.Id))
                    );

                update = Builders<Supplier>.Update
                    .Set("Warehouses.$", warehouse);
                var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });
            }
            else
            {
                warehouse.Id = Guid.NewGuid();
                filter = Builders<Supplier>.Filter.Eq(x => x.Id, supplierId);
                update = Builders<Supplier>.Update
                    .AddToSet(x => x.Warehouses, warehouse);
                var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });
            }

            return warehouse;
        }

        public bool DeleteWarehouse(Guid supplierId, Guid warehouseId)
        {
            var filter = Builders<Supplier>.Filter.And(
                    Builders<Supplier>.Filter.Eq(x => x.Id, supplierId),
                    Builders<Supplier>.Filter.ElemMatch(x => x.Warehouses, w => w.Id.Equals(warehouseId)));

            var delete = Builders<Supplier>.Update
                   .PullFilter(x=>x.Warehouses, w=> w.Id.Equals(warehouseId));

            var result = this.collection.UpdateOne(filter, delete);
            return result.MatchedCount > 0;
        }
    }
}
