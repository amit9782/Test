﻿using System;
using System.Collections.Generic;
using System.Linq;
using BornsToCode.Common.Data;
using BornsToCode.Common.Mongo;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using BornsToCode.Common.Extensions;
using MongoDB.Driver;
using BuyHQ.Core.Models;
using System.Linq.Expressions;

namespace BuyHQ.Data.MongoDb
{
    public class ProductRepository : MongoRepositoryBase<Product>, IProductRepository
    {
        public ProductRepository(string dbName) : base(dbName) { }
        public ProductRepository(string connectionString, string dbName) : base(connectionString, dbName) { }

        

        public IList<Product> GetProductsForCategory(Guid categoryId)
        {
            return this.Query()
                .Where(x => x.Categories.Any(c => c.Equals(categoryId)))
                .ToList(); 
        }

        public PagedResult<Product> GetProductsForCategoryAsPaged(Guid categoryId, int pageNo =1, int numberPerPage = 50)
        {
            return this.Query()
                .Where(x => x.Categories.Any(c => c.Equals(categoryId)))
                .ToPagedResult<Product>(Count(x => x.Categories.Any(c => c.Equals(categoryId))));
        }

        public PagedResult<ProductViewModel> GetProductViewModelForCategoryAsPaged(Guid categoryId, int pageNo = 1, int numberPerPage = 50)
        {
            return this.Query()
                .Where(x => x.Categories.Any(c => c.Equals(categoryId)))
                .Select(p => new ProductViewModel()
                {
                    Id = p.Id,
                    MPN = p.MPN,
                    Name = p.Name,
                    ProductImagePath = p.ProductImagePath,
                    RRP = p.RRP,
                    SellPriceInc = p.SellPriceInc,
                    ShortDescription = p.ShortDescription,
                    SKU = p.SKU,
                    SpecialBuyEndDate = p.SpecialBuyEndDate,
                    SpecialBuyStartDate = p.SpecialBuyStartDate,
                    VendorName = p.VendorName
                })
                .ToPagedResult<ProductViewModel>(Count(x => x.Categories.Any(c => c.Equals(categoryId))));
        }

        public PagedResult<ProductViewModel> ListProductViewModelAsPaged(Expression<Func<Product, bool>> expression = null, int pageNo = 1, int numberPerPage = 50)
        {
            throw new NotImplementedException();
        }

        public SupplierStock SaveSupplierStock(Guid productId, SupplierStock stock)
        {
            UpdateDefinition<Product> update;
            FilterDefinition<Product> filter;

            if (stock.Id != null && stock.Id != Guid.Empty)
            {
                filter = Builders<Product>.Filter.And(
                    Builders<Product>.Filter.Eq(x => x.Id, productId),
                    Builders<Product>.Filter.ElemMatch(x => x.SupplierStock, w => w.Id.Equals(stock.Id))
                    );

                update = Builders<Product>.Update
                    .Set("SupplierStock.$", stock);
                var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });
            }
            else
            {
                stock.Id = Guid.NewGuid();
                filter = Builders<Product>.Filter.Eq(x => x.Id, productId);
                update = Builders<Product>.Update
                    .AddToSet(x => x.SupplierStock, stock);
                var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });
            }

            return stock;
        }

        public bool AddImage(Guid productId, string imagePath, bool isDefault)
        {
            UpdateDefinition<Product> update;
            FilterDefinition<Product> filter;

            filter = Builders<Product>.Filter.Eq(x => x.Id, productId);
            update = Builders<Product>.Update
                .AddToSet(x => x.Images, new ProductImage() { Path = imagePath, IsDefault = isDefault });

            var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });

            return result.IsAcknowledged && result.MatchedCount == 1;
        }

        public bool SaveCategoriesForProduct(Guid productId, List<ProductCategory> categories)
        {
            UpdateDefinition<Product> update;
            FilterDefinition<Product> filter;

            filter = Builders<Product>.Filter.Eq(x => x.Id, productId);
            update = Builders<Product>.Update
                .Set(x => x.Categories, categories);

            var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });

            return result.IsAcknowledged && result.MatchedCount == 1;
        }
    }
}
