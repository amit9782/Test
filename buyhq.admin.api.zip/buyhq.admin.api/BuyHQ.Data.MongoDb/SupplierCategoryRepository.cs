﻿using BornsToCode.Common.Mongo;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using BuyHQ.Core.Util;
using System.Threading.Tasks;

namespace BuyHQ.Data.MongoDb
{
    public class SupplierCategoryRepository : MongoRepositoryBase<SupplierCategory>, ISupplierCategoryRepository
    {
        public SupplierCategoryRepository(string dbName) : base(dbName) { }
        public SupplierCategoryRepository(string connectionString, string dbName) : base(connectionString, dbName) { }

        public override SupplierCategory Save(SupplierCategory category)
        {
            category.Path = category.BuildBreadcrumb(this);
            return base.Save(category);
        }

        public override Task<SupplierCategory> SaveAsync(SupplierCategory category)
        {
            category.Path = category.BuildBreadcrumb(this);
            return base.SaveAsync(category);
        }
    }
}
