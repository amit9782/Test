﻿using BornsToCode.Common.Mongo;
using BuyHQ.Core.Repository;
using BuyHQ.Core.Models;

namespace BuyHQ.Data.MongoDb
{
    public class ProductImportRepository : MongoRepositoryBase<ProductImportModel>, IProductImportRepository
    {
        public ProductImportRepository(string dbName) : base(dbName) { }
        public ProductImportRepository(string connectionString, string dbName) : base(connectionString, dbName) { }

       


    }
}
