﻿using System;
using BornsToCode.Common.Mongo;
using BuyHQ.Core.Domain.Import;
using BuyHQ.Core.Repository;
using MongoDB.Driver;

namespace BuyHQ.Data.MongoDb
{
    public class ImportAgentRepository : MongoRepositoryBase<ImportAgentConfig>, IImportAgentRepository
    {
        public ImportAgentRepository(string dbName) : base(dbName) { }
        public ImportAgentRepository(string connectionString, string dbName) : base(connectionString, dbName) { }

        public void AddLog(Guid supplierId, ImportLog log)
        {
            var filter = Builders<ImportAgentConfig>.Filter.Eq(x => x.SupplierId, supplierId);
            var update = Builders<ImportAgentConfig>.Update
                .AddToSet(x => x.Log, log);
            var result = this.collection.UpdateOne(filter, update, new UpdateOptions() { IsUpsert = true });
        }
    }
}
