﻿using BornsToCode.Common.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BornsToCode.Common.Extensions
{
    public static class PagingExtensions
    {
        public static PagedResult<TEntity> ToPagedResult<TEntity>(this IQueryable<TEntity> query, long totalRecordCount, int currentPageNo = 1, int pageSize = 50)
        {
            var result = query
                            .Skip((currentPageNo - 1) * pageSize)
                            .Take(pageSize).ToList();

            return new PagedResult<TEntity>()
            {
                PageNumber = currentPageNo,
                PageSize = pageSize,
                TotalCount = totalRecordCount,
                Result = result
            };
        }



        public static async Task<PagedResult<TEntity>> ToPagedResultAsync<TEntity>(this IQueryable<TEntity> query, long totalRecordCount, int currentPageNo = 1, int pageSize = 50)
        {
            var result = query
                            .Skip((currentPageNo - 1) * pageSize)
                            .Take(pageSize)
                            .ToList();

            return new PagedResult<TEntity>()
            {
                PageNumber = currentPageNo,
                PageSize = pageSize,
                TotalCount = totalRecordCount,
                Result = result
            };
        }
    }
}
