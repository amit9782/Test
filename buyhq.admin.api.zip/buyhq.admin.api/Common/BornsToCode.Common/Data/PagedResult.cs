﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BornsToCode.Common.Data
{
    public enum SortDirection
    {
        Asc,
        Desc
    }

    public class PagedResult<T>
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        public long TotalCount { get; set; } = 0;

        public string SortField { get; set; }
        public SortDirection SortDirection { get; set; } = SortDirection.Desc;

        public List<T> Result { get; set; } = new List<T>();
    }
}
