﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using BornsToCode.Common.Entity;

namespace BornsToCode.Common.Data
{
    public interface IRepository<TEntity> //where TEntity: class
    {
        //IQueryable<TEntity> Query { get; set; }

        IEnumerable<TEntity> GetAll();
        Task<IEnumerable<TEntity>> GetAllAsync();

        TEntity GetOne(Expression<Func<TEntity, bool>> expression);
        Task<TEntity> GetOneAsync(Expression<Func<TEntity, bool>> expression);

        IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> expression);
        Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> expression);

        Task<TEntity> FindOneAsync(Expression<Func<TEntity, bool>> expression);
        TEntity FindOne(Expression<Func<TEntity, bool>> expression);

        long Count(Expression<Func<TEntity, bool>> expression);
        Task<long> CountAsync(Expression<Func<TEntity, bool>> expression);

        TEntity Save(TEntity entity);
        Task<TEntity> SaveAsync(TEntity entity);

        void Delete(TEntity entity);
        Task DeleteAsync(TEntity entity);
        void Delete(Expression<Func<TEntity, bool>> expression);
        Task DeleteAsync(Expression<Func<TEntity, bool>> expression);

        void InsertMany(IEnumerable<TEntity> items);
        Task InsertManyAsync(IEnumerable<TEntity> items);

        void SaveBulk(IEnumerable<TEntity> entites);
        Task SaveBulkAsync(IEnumerable<TEntity> entites);

        IQueryable<TEntity> Query();

        PagedResult<TEntity> GetAllAsPaged( int currentPageNo = 1, int pageSize = 20);
        Task<PagedResult<TEntity>> GetAllAsPagedAsync(int currentPageNo = 1, int pageSize = 20);

        PagedResult<TEntity> FindAsPaged(Expression<Func<TEntity, bool>> expression, int currentPageNo, int pageSize);
        Task<PagedResult<TEntity>> FindAsPagedAsync(Expression<Func<TEntity, bool>> expression, int currentPageNo, int pageSize);


        //TChild SaveChild<TChild>(Guid parentId,
        //                         Guid childId,
        //                         Expression<Func<TEntity, List<TChild>>> childCollectionExpression,
        //                         Expression<Func<TChild, object>> childIdFieldExpression,
        //                         TChild childEntity) where TChild : IEntityWithKey<Guid>;

        //TChild SaveChild<TChild>(Guid parentId,
        //                         Guid childId,
        //                         string childCollectionPath,
        //                         string childIdFieldPath, TChild model) where TChild : IEntityWithKey<Guid>;
        ////void InsertOne(TEntity item);
        //Task InsertOneAsync(TEntity item);


    }
}
