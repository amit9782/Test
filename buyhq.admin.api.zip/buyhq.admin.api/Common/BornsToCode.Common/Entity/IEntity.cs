﻿using System;

namespace BornsToCode.Common.Entity
{
    public interface IEntityWithKey<TKey>
    {
        TKey Id { get; set; }
    }

    public interface IEntityAuditWithKey<TKey>
    {
        TKey Id { get; set; }

        TKey CreatedById { get; set; }
        string CreatedBy { get; set; }
        DateTime Created { get; set; }

        TKey ModifiedById { get; set; }
        string ModifiedBy { get; set; }
        DateTime Modified { get; set; }
    }
}
