﻿using System;
using System.Linq.Expressions;

namespace BornsToCode.Common
{
    /// <summary>
    /// The PropertyNameResolver static class provides utility methods to generate strings representing field-member access for use in MongoDB query and update operations.
    /// This allows you to use lambda expressions to represent the properties you wish to use for query or update instead of coding literal string values to represent those members.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public static class PropertyNameResolver<T>
    {
        /// <summary>
        /// Returns a string representation of the specified expression.  This allows you to strongly type your query criteria, so they can be passed back to Mongo as strings.
        /// </summary>
        /// <param name="expression">A member expression on the record type.</param>
        /// <returns>A string representing the member expression</returns>
        public static string PropertyName<S>(Expression<Func<T, S>> expression)
        {
            // TODO - Add caching here if the lambdas get to be too expensive?  But the cache may not help if the building of the expression is actually the expensive part
            MemberExpression expressionBody = expression.Body as MemberExpression;
            if (expressionBody == null)
            {
                throw new ApplicationException("Expression must be member access.");
            }
            return Resolve(expression);
        }

        /// <summary>
        /// Resolves a member-access expression into a dotted-string suitable for using in a MongoDB query or update statement.
        /// </summary>
        /// <typeparam name="S"></typeparam>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static string Resolve<S>(Expression<Func<T, S>> expression)
        {
            MemberExpression member = expression.Body as MemberExpression;
            if (member == null)
            {
                return String.Empty;
            }
            else
            {
                return ResolveRecursiveMemberName(member);
            }
        }

        public static string ResolveRecursiveMemberName(Expression expression)
        {
            MemberExpression memberExpression = expression as MemberExpression;
            if (memberExpression != null)
            {
                var prefix = ResolveRecursiveMemberName(memberExpression.Expression);
                if (prefix != String.Empty)
                {
                    return String.Concat(prefix, ".", memberExpression.Member.Name);
                }
                else
                {
                    return memberExpression.Member.Name;
                }
            }
            MethodCallExpression methodCallExpression = expression as MethodCallExpression;
            if (methodCallExpression != null && ((methodCallExpression.Method.DeclaringType == typeof(System.Linq.Enumerable) && (methodCallExpression.Method.Name == "Single")) || methodCallExpression.Method.Name == "Member"))
            {
                return ResolveRecursiveMemberName(methodCallExpression.Arguments[0]);
            }
            else
            {
                return String.Empty;
            }
        }
    }
}