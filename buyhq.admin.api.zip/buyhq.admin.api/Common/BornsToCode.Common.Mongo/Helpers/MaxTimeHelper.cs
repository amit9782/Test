﻿using System;
using System.Threading;

namespace BornsToCode.Common.Mongo.Helpers
{
    public static class MaxTimeHelper
    {
        public static int ToMaxTimeMS(TimeSpan value)
        {
            if (value == Timeout.InfiniteTimeSpan)
            {
                return 0;
            }
            else if (value < TimeSpan.Zero)
            {
                throw new ArgumentOutOfRangeException(nameof(value));
            }
            else
            {
                return (int)Math.Ceiling(value.TotalMilliseconds);
            }
        }
    }
}
