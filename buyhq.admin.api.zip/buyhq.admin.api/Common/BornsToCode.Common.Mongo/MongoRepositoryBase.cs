﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

using BornsToCode.Common.Data;
using BornsToCode.Common.Entity;
using BornsToCode.Common.Extensions.String;
using MongoDB.Bson;
using MongoDB.Driver;

namespace BornsToCode.Common.Mongo
{
    public abstract class MongoRepositoryBase<TEntity> : IRepository<TEntity> where TEntity : IEntityWithKey<Guid>
    {
        protected IMongoClient client;
        protected IMongoDatabase db;
        protected IMongoCollection<TEntity> collection;

        public MongoRepositoryBase(string database) : this("mongodb://127.0.0.1:27017", database, typeof(TEntity).Name.ToLower().Pluralize()) { }

        public MongoRepositoryBase(string connectionString, string database) : this(connectionString, database, typeof(TEntity).Name.ToLower().Pluralize()) { }

        /// <summary>
        /// Constructor for setting up the repository
        /// </summary>
        /// <param name="connectionString">Server address i.e. mongodb://localhost:27017</param>
        /// <param name="database">Mongo Database name</param>
        /// <param name="collectionName">Collection we're dealing with</param>
        public MongoRepositoryBase(string connectionString, string database, string collectionName)
        {
            //var dbs = client.ListDatabases();

            client = new MongoClient(connectionString);

            db = client.GetDatabase(database);
            db.WithWriteConcern(WriteConcern.Acknowledged);
            collection = this.db.GetCollection<TEntity>(collectionName);
        }

        public virtual void Delete(TEntity entity)
        {
            collection.DeleteOne(x => x.Id.Equals(entity.Id));
        }

        public virtual void Delete(Expression<Func<TEntity, bool>> expression)
        {
            collection.DeleteOne(expression);
        }

        public virtual async Task DeleteAsync(TEntity entity)
        {
            await collection.DeleteOneAsync(x => x.Id.Equals(entity.Id))
                .ConfigureAwait(false);
        }

        public virtual async Task DeleteAsync(Expression<Func<TEntity, bool>> expression)
        {
            await collection.DeleteOneAsync(expression)
                .ConfigureAwait(false);
        }

        public virtual IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> expression)
        {
            return collection.Find(expression).ToList();
        }

        public virtual async Task<TEntity> FindOneAsync(Expression<Func<TEntity, bool>> expression)
        {
            return await collection.Find(expression)
                .FirstOrDefaultAsync()
                .ConfigureAwait(false);
        }

        public virtual TEntity FindOne(Expression<Func<TEntity, bool>> expression)
        {
            return collection.Find(expression).FirstOrDefault();
        }

        public virtual async Task<IEnumerable<TEntity>> FindAsync(Expression<Func<TEntity, bool>> expression)
        {
            return await collection.Find(expression).ToListAsync()
                .ConfigureAwait(false);
        }

        public virtual IEnumerable<TEntity> GetAll()
        {
            return collection.AsQueryable<TEntity>().ToList();
        }

        public virtual async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await collection.AsQueryable<TEntity>().ToListAsync()
                .ConfigureAwait(false);
        }

        public virtual TEntity GetOne(Expression<Func<TEntity, bool>> expression)
        {
            return collection.Find(expression).FirstOrDefault();
        }

        public virtual async Task<TEntity> GetOneAsync(Expression<Func<TEntity, bool>> expression)
        {
            return await collection.Find(expression).FirstOrDefaultAsync()
                .ConfigureAwait(false);
        }

        public virtual long Count(Expression<Func<TEntity, bool>> expression)
        {
            return collection.CountDocuments(expression);
        }

        public virtual async Task<long> CountAsync(Expression<Func<TEntity, bool>> expression)
        {
            return await collection.CountDocumentsAsync(expression);
        }

        public virtual void InsertMany(IEnumerable<TEntity> items)
        {
            collection.InsertMany(items, new InsertManyOptions { IsOrdered = false, BypassDocumentValidation = true });
        }

        public virtual async Task InsertManyAsync(IEnumerable<TEntity> items)
        {
            await collection.InsertManyAsync(items, new InsertManyOptions { IsOrdered = false, BypassDocumentValidation = true })
                .ConfigureAwait(false);
        }

        public IQueryable<TEntity> Query()
        {
            return collection.AsQueryable();
        }

        public virtual TEntity Save(TEntity entity)
        {
            if (entity.Id == Guid.Empty || entity.Id == Guid.Empty)
                entity.Id = Guid.NewGuid(); //ObjectId.GenerateNewId();

            collection.ReplaceOne(x => x.Id.Equals(entity.Id), entity, new UpdateOptions
            {
                IsUpsert = true
            });
            return entity;
        }

        public virtual async Task<TEntity> SaveAsync(TEntity entity)
        {
            if (entity.Id == Guid.Empty)
                entity.Id = Guid.NewGuid();//ObjectId.GenerateNewId();

            await collection.ReplaceOneAsync(x => x.Id.Equals(entity.Id), entity, new UpdateOptions
            {
                IsUpsert = true
            }).ConfigureAwait(false);
            return entity;
        }

        public virtual void SaveBulk(IEnumerable<TEntity> entites)
        {
            List<WriteModel<TEntity>> bulkOps = new List<WriteModel<TEntity>>();

            foreach (var entity in entites)
            {
                if (entity.Id == Guid.Empty)
                    entity.Id = Guid.NewGuid();//ObjectId.GenerateNewId();
                var upsertOne = new ReplaceOneModel<TEntity>(
                                Builders<TEntity>.Filter.Where(x => x.Id == entity.Id), entity)
                {
                    IsUpsert = true
                };
                bulkOps.Add(upsertOne);
            }
            // TODO: Probably should do something with this
            collection.BulkWrite(bulkOps);
        }

        public virtual async Task SaveBulkAsync(IEnumerable<TEntity> entites)
        {
            List<WriteModel<TEntity>> bulkOps = new List<WriteModel<TEntity>>();

            foreach (var entity in entites)
            {
                if (entity.Id == Guid.Empty)
                    entity.Id = Guid.NewGuid();//ObjectId.GenerateNewId();
                var upsertOne = new ReplaceOneModel<TEntity>(
                                Builders<TEntity>.Filter.Where(x => x.Id == entity.Id), entity)
                {
                    IsUpsert = true
                };
                bulkOps.Add(upsertOne);

            }
            // TODO: Probably should do something with this
            var result = await collection.BulkWriteAsync(bulkOps)
                .ConfigureAwait(false);
        }


        #region paging

        public PagedResult<TEntity> GetAllAsPaged(int currentPageNo = 1, int pageSize = 20)
        {
            //MongoDB.Driver.Le.MongoCursor<BsonDocument>
            // todo: look at MonogoDB.Driver.Legacy for curser impl
            var result = collection.AsQueryable<TEntity>()
                            .Skip((currentPageNo - 1) * pageSize)
                            .Take(pageSize).ToList();

            return new PagedResult<TEntity>()
            {
                PageNumber = currentPageNo,
                PageSize = pageSize,
                TotalCount = collection.CountDocuments(new BsonDocument()),
                Result = result
            };
        }

        public async Task<PagedResult<TEntity>> GetAllAsPagedAsync(int currentPageNo = 1, int pageSize = 20)
        {
            //MongoDB.Driver.Le.MongoCursor<BsonDocument>
            // todo: look at MonogoDB.Driver.Legacy for curser impl
            // Also, .FindAsync returns a cursor

            var result = collection.AsQueryable<TEntity>()
                            .Skip((currentPageNo - 1) * pageSize)
                            .Take(pageSize)
                            .ToList();

            return new PagedResult<TEntity>()
            {
                PageNumber = currentPageNo,
                PageSize = pageSize,
                TotalCount = await collection.CountDocumentsAsync(new BsonDocument()),
                Result = result
            };

        }

        public PagedResult<TEntity> FindAsPaged(Expression<Func<TEntity, bool>> expression, int currentPageNo, int pageSize)
        {
            //MongoDB.Driver.Le.MongoCursor<BsonDocument>
            // todo: look at MonogoDB.Driver.Legacy for curser impl
            var result =  collection.Find(expression)
                            .Skip((currentPageNo - 1) * pageSize)
                            .Limit(pageSize);

            return new PagedResult<TEntity>()
            {
                PageNumber = currentPageNo,
                PageSize = pageSize,
                TotalCount = Count(expression),
                Result = result.ToList()
            };

        }

        public async Task<PagedResult<TEntity>> FindAsPagedAsync(Expression<Func<TEntity, bool>> expression, int currentPageNo, int pageSize)
        {
            //MongoDB.Driver.Le.MongoCursor<BsonDocument>
            // todo: look at MonogoDB.Driver.Legacy for curser impl
            // Also, .FindAsync returns a cursor

            var result = await collection.Find(expression)
                            .Skip((currentPageNo - 1) * pageSize)
                            .Limit(pageSize)
                            .ToListAsync();

            return new PagedResult<TEntity>()
                {
                    PageNumber = currentPageNo,
                    PageSize = pageSize,
                    TotalCount = await CountAsync(expression),
                    Result = result
                };

        }

        #endregion

        #region child collection specific tasks

        //public virtual TChild SaveChild<TChild>(Guid parentId, 
        //                                        Guid childId, 
        //                                        string childCollectionPath,
        //                                        string childIdFieldPath, TChild model) where TChild : IEntityWithKey<Guid>
        //{
        //    if(childId != Guid.Empty) // existing
        //    {
        //        var filter = Builders<TChild>.Filter.Eq(x => x.Id, childId);
        //        //var update = Builders<TChild>.Update.Set()


            
        //    return model;   
        //}

        //public virtual TChild SaveChild<TChild>(Guid parentId, 
        //                                        Guid childId, 
        //                                        Expression<Func<TEntity, List<TChild>>> childCollectionExpression, 
        //                                        Expression<Func<TChild, object>> childIdFieldExpression, 
        //                                        TChild childEntity)  where TChild : IEntityWithKey<Guid>
        //{

        //    // https://stackoverflow.com/questions/14313649/update-delete-a-sub-document-in-mongodb-using-c-sharp-driver/14315531
        //    //if (childEntity.Id == Guid.Empty)
        //        //childEntity.Id = Guid.NewGuid(); //ObjectId.GenerateNewId();

        //    if (childId != Guid.Empty) // existing
        //    {
        //        var filter = Builders<TChild>.Filter.Eq(x => x.Id, childId);
        //        var update = Builders<TChild>.Update.Set(childCollectionExpression)


        //        }
        //    return model; 

        //    //string childIdPropertyName = PropertyNameResolver<TEntity>.
        //    //                                                          ResolveRecursiveMemberName(childCollectionExpression);
        //    //string childCollectionPropertyName = PropertyNameResolver<TChild>
        //        //.ResolveRecursiveMemberName(childIdFieldExpression);

        //    //var filter = Builders<TEntity>.Filter.And(
        //        //Builders<TEntity>.Filter.Eq(x => x.Id, parentId),
        //        //Builders<TEntity>.Filter.Eq(childIdPropertyName, childId));

        //    //collection.FindOneAndUpdate(filter, childEntity);
        //    //collection.ReplaceOne(filter, childEntity, new UpdateOptions
        //    //{
        //    //    IsUpsert = true
        //    //});
        //    return childEntity;
        //}

        public virtual async Task<TEntity> SaveChildAsync(TEntity entity) 
        {
            if (entity.Id == Guid.Empty)
                entity.Id = Guid.NewGuid();//ObjectId.GenerateNewId();

            await collection.ReplaceOneAsync(x => x.Id.Equals(entity.Id), entity, new UpdateOptions
            {
                IsUpsert = true
            }).ConfigureAwait(false);
            return entity;
        }

        #endregion
    }
}
