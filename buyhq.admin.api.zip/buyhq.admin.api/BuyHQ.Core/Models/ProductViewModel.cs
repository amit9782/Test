﻿using BuyHQ.Core.Domain;
using System;
using System.Collections.Generic;

namespace BuyHQ.Core.Models
{
    public class ProductViewModel
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string SKU { get; set; }

        public string MPN { get; set; }

        public string VendorName { get; set; }

        public string ShortDescription { get; set; }

        public decimal RRP { get; set; }

        public decimal SellPriceInc { get; set; }

        
        public DateTime? SpecialBuyStartDate { get; set; }

        public DateTime? SpecialBuyEndDate { get; set; }

        public decimal BestBuyPriceEx { get; set; }
        public decimal BestBuyPriceInc { get; set; }

        public Guid BestBuySupplierId { get; set; }
        public string BestBuySupplierName { get; set; }

        public string ProductImagePath { get; set; }

        public List<SupplierStock> SupplierStock { get; set; } = new List<SupplierStock>();


    }
}
