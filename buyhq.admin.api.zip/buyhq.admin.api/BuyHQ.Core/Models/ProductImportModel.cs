﻿using BornsToCode.Common.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BuyHQ.Core.Models
{
    public class ProductImportModel : IEntityWithKey<Guid>
    {
        public ProductImportModel()
        {
            ImportDateTimeUTC = DateTime.UtcNow;
        }

        public Guid Id { get; set; }

        public Guid SupplierId { get; set; }

        [Display(Name = "Product name", Description = "The name of the product", GroupName = "Product info")]
        public string Name { get; set; }

        [Display(Name = "Internal Stock code", Description = "Your stock code", GroupName = "Product info"), MaxLength(155)]
        public string SKU { get; set; }

        [Display(Name = "Supplier stock code", Description = "The suppliers stock code", GroupName = "Product info"), MaxLength(255)]
        public string SupplierSKU { get; set; }

        [Display(Name = "Manufacturer stock number", Description = "The stock number or code as defined by the manufacturer", GroupName = "Product info"), MaxLength(255)]
        public string MSN { get; set; }

        [Display(Name = "Manufacturer part number", Description = "The part number or code as defined by the manufacturer", GroupName = "Product info"), MaxLength(255)]
        public string MPN { get; set; }

        [Display(Name = "Manufacturer UPC code", Description = "The part number or code as defined by the manufacturer", GroupName = "Product info"), MaxLength(255)]
        public string UPC { get; set; }

        [Display(Name = "Manufacturer EAN code", Description = "The part number or code as defined by the manufacturer", GroupName = "Product info"), MaxLength(255)]
        public string EAN { get; set; }

        [Display(Name = "Vendor name", Description = "The vendor / brand of the product", GroupName = "Product info"), MaxLength(255)]
        public string VendorName { get; set; }



        [Display(Name = "Short description", Description = "Product brief description", GroupName = "Product info"), MaxLength(1000)]
        public string ShortDescription { get; set; }

        [Display(Name = "Full description", Description = "Product full description", GroupName = "Product info")]
        public string FullDescription { get; set; }


        [Display(Name = "Product image", Description = "Path or URL to the product, can be assigned to multiple fields", GroupName = "Product info")]
        public string ImagePath { get; set; }

        [Display(Name = "Affiliate link", Description = "Affiliate link", GroupName = "Product info")]
        public string AffiliateLink { get; set; }

        [Display(Name = "Primary category", Description = "Primary product category as defined by the supplier", GroupName = "Product info"), MaxLength(255)]
        public string PrimaryCategory { get; set; }

        [Display(Name = "Secondary category", Description = "Secondary product category as defined by the supplier", GroupName = "Product info"), MaxLength(255)]
        public string SecondaryCategory { get; set; }

        [Display(Name = "Tertiary category", Description = "Tertiary product category as defined by the supplier", GroupName = "Product info"), MaxLength(255)]
        public string TertiaryCategory { get; set; }

        [Display(Name = "RRP inc.", Description = "Recommended Retail Price (assumes inclusive of taxes)", GroupName = "Pricing"), DefaultValue(-1)]
        public decimal? RRP { get; set; }

        [Display(Name = "RRP ex.", Description = "Recommended Retail Price (exclusive of taxes)", GroupName = "Pricing"), DefaultValue(-1)]
        public decimal? RRPEx { get; set; }

        [Display(Name = "Buy Ex.", Description = "Buy price exclusive of tax", GroupName = "Pricing"), DefaultValue(-1)]
        public decimal BuyEx { get; set; }

        [Display(Name = "Buy inc.", Description = "Buy price inclusive of tax", GroupName = "Pricing"), DefaultValue(-1)]
        public decimal BuyInc { get; set; }

        [Display(Name = "Special buy Ex.", Description = "Buy price exclusive of tax", GroupName = "Pricing"), DefaultValue(-1)]
        public decimal SpecialBuyEx { get; set; }

        [Display(Name = "Special buy inc.", Description = "Buy price inclusive of tax", GroupName = "Pricing"), DefaultValue(-1)]
        public decimal SpecialBuyInc { get; set; }

        [Display(Name = "Special buy price start", Description = "Special buy price start date", GroupName = "Pricing")]
        public DateTime? SpecialBuyStartDate { get; set; }

        [Display(Name = "Special buy price end", Description = "Special buy price end date", GroupName = "Pricing")]
        public DateTime? SpecialBuyEndDate { get; set; }





        [Display(Name = "Stock on hand", Description = "Total number of in stock with the supplier", GroupName = "Stock"), DefaultValue(-1)]
        public decimal StockOnHand { get; set; }

        [Display(Name = "Stock ETA", Description = "ETA for stock", GroupName = "Stock")]
        public DateTime? StockETA { get; set; }

        [Display(Name = "Vic warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? VIC_Stock { get; set; }

        [Display(Name = "NSW warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? NSW_Stock { get; set; }

        [Display(Name = "QLD warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? QLD_Stock { get; set; }

        [Display(Name = "WA warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? WA_Stock { get; set; }

        [Display(Name = "NT warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? NT_Stock { get; set; }

        [Display(Name = "ACT warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? ACT_Stock { get; set; }

        [Display(Name = "SA warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? SA_Stock { get; set; }

        [Display(Name = "Other warehouse stock", GroupName = "Stock"), DefaultValue(0)]
        public decimal? OtherLocation_Stock { get; set; }

        //[Display(Name = "Import date", Description = "Date and time (UTC) the item was imported")]
        public DateTime? ImportDateTimeUTC { get; set; }

        [Display(Name = "Warranty duration", Description = "Duration products warranty (in days)", GroupName = "Misc."), DefaultValue(-1)]
        public int? WarrantyDuration { get; set; }

        [Display(Name = "Warranty info", Description = "Information about products warranty", GroupName = "Misc.")]
        public string WarrantyInfo { get; set; }

        public bool IsLicense { get; set; }
        public bool IsBundle { get; set; }
        public bool IsWarranty { get; set; }


        public decimal Length { get; set; }
        public decimal Height { get; set; }
        public decimal Width { get; set; }
        public decimal Weight { get; set; }
        public decimal Volume { get; set; }

        /// <summary>
        /// Product unit (i.e ea)
        /// </summary>
        /// <value>The unit.</value>
		public string Unit { get; set; }

        public string DimensionUnit { get; set; }
        public string WeightUnit { get; set; }
        public string VolumeUnit { get; set; }
        public decimal BackOrder { get; set; }

        public string SubstituteProductCode { get; set; }
        public string SuperceededProductCode { get; set; }

        /// <summary>
        /// Stores associated products. 
        /// <string, string> For associated product code and association type
        /// </summary>
        /// <value>The associated products.</value>
        public Dictionary<string, string> AssociatedProducts { get; set; }

        #region extended attributes

        // TODO: This should be refactored to a Key/Value Pair setup to allow this to be more dynamic.
        // But for the time being well stick to KISS


        [Display(Name = "Colour", Description = "", GroupName = "Misc."), MaxLength(255)]
        public string Color { get; set; }

        [Display(Name = "Delivery time", Description = "Expected delivery time", GroupName = "Misc.")]
        public string DeliveryTime { get; set; }

        [Display(Name = "Delivery cost", Description = "", GroupName = "Misc.")]
        public string DeliveryCost { get; set; }

        [Display(Name = "Size", Description = "Usually used for clothing or garments", GroupName = "Misc.")]
        public string Size { get; set; }

        [Display(Name = "Gender", Description = "", GroupName = "Misc."), MaxLength(255)]
        public string Gender { get; set; }

        [Display(Name = "Genre", Description = "", GroupName = "Misc."), MaxLength(255)]
        public string Genre { get; set; }

        [Display(Name = "Keywords", Description = "", GroupName = "Misc.")]
        public string Keywords { get; set; }

        [Display(Name = "Star rating", Description = "Based on reviews or content rating", GroupName = "Misc.")]
        public string StarRating { get; set; }

        [Display(Name = "Promo text", Description = "Promotional text", GroupName = "Misc.")]
        public string PromoText { get; set; }



        #endregion



    }
}