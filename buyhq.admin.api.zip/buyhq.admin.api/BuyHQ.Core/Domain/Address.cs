﻿using BornsToCode.Common.Entity;
using System;

namespace BuyHQ.Core.Domain
{
    public class Address : IEntityWithKey<Guid>
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Suburb { get; set; }
        public string State { get; set; }
        public string PostCode { get; set; }
        public string Country { get; set; }

        public double Long { get; set; }
        public double Lat { get; set; }
    }
}