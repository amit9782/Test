﻿using System;
using System.Collections.Generic;

namespace BuyHQ.Core.Domain
{
    public class SupplierStock : VersionedEntityBase
    {
        public Guid SupplierId { get; set; }
        public string SupplierName { get; set; }

        public string SupplierProductName { get; set; }

        public string SupplierSku { get; set; }

        /// <summary>
        /// Aggregate of all stock from all warehouses
        /// </summary>
        public decimal StockOnHand { get; set; }

        public Guid WarehouseId { get; set; }
        public string Warehouse { get; set; }

        public decimal BuyEx { get; set; }
        public decimal BuyInc { get; set; }

        public DateTime SpecialStart { get; set; }
        public DateTime SpecialEnd { get; set; }

        public decimal SpecialBuyEx { get; set; }
        public decimal SpecialBuyInc { get; set; }

        public List<PriceHistory> PriceHistory { get; set; } = new List<PriceHistory>();

        public bool HasChanges(decimal buyEx, decimal specialBuyEx, decimal soh)
        {
            return !buyEx.Equals(BuyEx) || !specialBuyEx.Equals(specialBuyEx) || !soh.Equals(StockOnHand);
        }
    }
}