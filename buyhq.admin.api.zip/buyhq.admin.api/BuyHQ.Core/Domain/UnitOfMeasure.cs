﻿namespace BuyHQ.Core.Domain
{
    public class UnitOfMeasure : EntityBase
    {
        public bool IsPrimaryUnit { get; set; }

        public string FriendlyName { get; set; }

        public string SystemName { get; set; }

        public decimal RatioToPrimary { get; set; }
    }
}