﻿using System;
using System.Collections.Generic;

namespace BuyHQ.Core.Domain.Import
{
    public class ImportAgentConfig : EntityBase
    {
        public Guid SupplierId { get; set; }
        public string SupplierName { get; set; }
        public string Assembly { get; set; }

        public IList<ImportLog> Log { get; set; } = new List<ImportLog>();

    }
}
