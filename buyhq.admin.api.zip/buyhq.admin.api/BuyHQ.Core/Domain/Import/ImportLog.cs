﻿using System;

namespace BuyHQ.Core.Domain.Import
{
    public class ImportLog
    {
        public DateTime Started { get; set; }
        public DateTime Finished { get; set; }
        public TimeSpan TimeTaken { get; set; }

        public bool Success { get; set; }
        public string Result { get; set; }

        public int NumberImported { get; set; }
        public int NumberNew { get; set; }
        public int NumberUnchanged { get; set; }
        public int NumberDeleted { get; set; }

    }
}
