﻿using BornsToCode.Common.Entity;
using System;

namespace BuyHQ.Core.Domain
{
    public abstract class EntityBase: IEntityWithKey<Guid>
    {
        public Guid Id { get; set; }

    }
}
