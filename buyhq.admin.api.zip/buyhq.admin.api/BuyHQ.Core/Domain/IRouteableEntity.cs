﻿namespace BuyHQ.Core.Domain
{
    public interface IRouteableEntity
    {
        string SeoKeywords { get; set; }

        string SeoTitle { get; set; }

        string SeoDescription { get; set; }

        string Slug { get; set; }
    }
}