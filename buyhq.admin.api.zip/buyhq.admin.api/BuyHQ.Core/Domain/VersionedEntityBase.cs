﻿using BornsToCode.Common.Entity;
using System;

namespace BuyHQ.Core.Domain
{
    public abstract class VersionedEntityBase : EntityBase, IEntityAuditWithKey<Guid>
    {
        public DateTime Created { get; set; }
        public Guid CreatedById { get; set; }
        public string CreatedBy { get; set; }

        public DateTime Modified { get; set; }
        public Guid ModifiedById { get; set; }
        public string ModifiedBy { get; set; }

    }
}
