﻿using System;
using System.Collections.Generic;

namespace BuyHQ.Core.Domain
{
    public class Category : EntityBase, IRouteableEntity
    {
        //public bool IsRoot { get; set; }

        public Guid ParentCategoryId { get; set; }

        public string Name { get; set; }
        public string Description { get; set; }

        public string Path { get; set; }

        public string SeoKeywords { get; set; }
        public string SeoTitle { get; set; }
        public string SeoDescription { get; set; }
        public string Slug { get; set; }
    }
}