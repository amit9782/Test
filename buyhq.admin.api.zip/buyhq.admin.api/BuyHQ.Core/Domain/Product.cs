﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.Options;

namespace BuyHQ.Core.Domain
{
    public class Product : ProductBase, IRouteableEntity
    {
        public string SeoKeywords { get; set; }

        public string SeoTitle { get; set; }

        public string SeoDescription { get; set; }

        public string Slug { get; set; }

        public bool IsActive { get; set; }

        public decimal BestBuyPriceEx { get; set; }
        public decimal BestBuyPriceInc { get; set; }

        public Guid BestBuySupplierId { get; set; }
        public string BestBuySupplierName { get; set; }


        /// <summary>
        /// Lists all supplier data for this product
        /// </summary>
        public List<SupplierStock> SupplierStock { get; set; } = new List<SupplierStock>();

        /// <summary>
        /// List of categories this product is to be displayed in
        /// </summary> 
        public List<ProductCategory> Categories { get; set; } = new List<ProductCategory>();
        //public Dictionary<Guid, string> Categories { get; set; } = new Dictionary<Guid, string>();

        /// <summary>
        /// Collection of images belonging to this product
        /// </summary>
        public List<ProductImage> Images { get; set; } = new List<ProductImage>();

    }
}
