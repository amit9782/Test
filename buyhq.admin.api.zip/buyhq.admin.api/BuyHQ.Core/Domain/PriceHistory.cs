﻿using System;

namespace BuyHQ.Core.Domain
{
    public class PriceHistory
    {
        public DateTime ChangeDate { get; set; }
        public decimal PreviousPrice { get; set; }
        public decimal CurrentPrice { get; set; }

        private decimal perc = 0;

        public decimal PercentageChange {
            get
            {
                if(perc == 0)
                {
                    if(PreviousPrice > 0)
                    {
                        var diff = PreviousPrice - CurrentPrice;
                        perc = diff / PreviousPrice;
                    }
                }
                return perc;
            }
            set
            {
                perc = value;
            }
        }
    }
}
