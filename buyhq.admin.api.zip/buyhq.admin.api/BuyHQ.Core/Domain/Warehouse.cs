﻿using BornsToCode.Common.Entity;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace BuyHQ.Core.Domain
{
    public class Warehouse : IEntityWithKey<Guid>
    {
        [BsonId]
        public Guid Id { get; set; } //= Guid.NewGuid();


        //public Guid SupplierId { get; set; }
        public string Name { get; set; }

        /// <summary>
        /// This is the field or delimiter that defines which warehouse stock is at
        /// </summary>
        public string ImportKey { get; set; }

        public  Address Address { get; set; }

        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
    }
}