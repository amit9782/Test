﻿using System;
using System.Collections.Generic;

namespace BuyHQ.Core.Domain
{
    public class SupplierCategory : EntityBase
    {
        public Guid SupplierId { get; set; }

        public Guid ParentCategoryId { get; set; }
        public string ParentCategory { get; set; }

        /// <summary>
        /// This is the Id the supplier uses (in case of a umber or tracking id)
        /// </summary>
        public string SupplierCategoryId { get; set; }

        public string Name { get; set; }
        public string Description { get; set; }

        public string Path { get; set; }

        /// <summary>
        /// Defines which of our categories this maps to
        /// </summary>
        public List<Guid> MapsToCategories { get; set; } = new List<Guid>();
    }
}