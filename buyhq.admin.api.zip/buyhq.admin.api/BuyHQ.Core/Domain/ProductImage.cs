﻿namespace BuyHQ.Core.Domain
{
    public class ProductImage
    {
        public bool IsDefault { get; set; }
        public string Path { get; set; }

        public string Title { get; set; }
    }
}