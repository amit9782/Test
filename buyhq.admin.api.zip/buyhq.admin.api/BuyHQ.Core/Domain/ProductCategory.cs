﻿using System;

namespace BuyHQ.Core.Domain
{
    public class ProductCategory
    {
        public ProductCategory(){}
        public ProductCategory(Guid id, string path){
            CategoryId = id;
            CategoryPath = path;
        }

        public Guid CategoryId { get; set; }
        public string CategoryPath { get; set; }
    }
}