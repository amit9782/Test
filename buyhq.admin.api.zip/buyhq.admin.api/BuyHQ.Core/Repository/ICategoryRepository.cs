﻿using BuyHQ.Core.Domain;
using BornsToCode.Common.Data;
using System.Collections.Generic;
using System;

namespace BuyHQ.Core.Repository
{
    public interface ICategoryRepository : IRepository<Category> {
        IList<Category> FindManyById(List<Guid> ids);
    }


}
