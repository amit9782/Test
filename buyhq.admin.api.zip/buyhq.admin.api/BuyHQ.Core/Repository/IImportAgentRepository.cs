﻿using BornsToCode.Common.Data;
using BuyHQ.Core.Domain.Import;
using System;

namespace BuyHQ.Core.Repository
{
    public interface IImportAgentRepository : IRepository<ImportAgentConfig> {
        void AddLog(Guid supplierId, ImportLog log);
    }

}
