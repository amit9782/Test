﻿using System;
using System.Collections.Generic;
using BornsToCode.Common.Data;
using BuyHQ.Core.Domain;

namespace BuyHQ.Core.Repository
{
    public interface ISupplierRepository : IRepository<Supplier>
    {
       // IList<Warehouse> GetWarehouses(Guid supplierId);
        Warehouse SaveWarehouse(Guid supplierId, Warehouse warehouse);
        bool DeleteWarehouse(Guid supplierId, Guid warehouseId);
    }
}
