﻿using BornsToCode.Common.Data;
using BuyHQ.Core.Models;

namespace BuyHQ.Core.Repository
{
    public interface IProductImportRepository : IRepository<ProductImportModel>
    {
        
    }


}
