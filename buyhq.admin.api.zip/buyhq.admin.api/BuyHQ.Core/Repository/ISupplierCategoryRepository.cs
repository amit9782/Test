﻿using BuyHQ.Core.Domain;
using BornsToCode.Common.Data;


namespace BuyHQ.Core.Repository
{
    public interface ISupplierCategoryRepository : IRepository<SupplierCategory> { }


}
