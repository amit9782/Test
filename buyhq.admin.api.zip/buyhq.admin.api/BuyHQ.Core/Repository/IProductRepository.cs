﻿using BuyHQ.Core.Domain;
using System;
using BornsToCode.Common.Data;
using System.Collections.Generic;
using BuyHQ.Core.Models;
using System.Linq.Expressions;

namespace BuyHQ.Core.Repository
{
    public interface IProductRepository : IRepository<Product>
    {
        SupplierStock SaveSupplierStock(Guid productId, SupplierStock stock);

        IList<Product> GetProductsForCategory(Guid categoryId);
        PagedResult<Product> GetProductsForCategoryAsPaged(Guid categoryId, int pageNo = 1, int numberPerPage = 50);

        PagedResult<ProductViewModel> ListProductViewModelAsPaged(Expression<Func<Product, bool>> expression = null, int pageNo = 1, int numberPerPage = 50);
        PagedResult<ProductViewModel> GetProductViewModelForCategoryAsPaged(Guid categoryId, int pageNo = 1, int numberPerPage = 50);

        bool AddImage(Guid productId, string imagePath, bool isDefault = false);

        bool SaveCategoriesForProduct(Guid productId, List<ProductCategory> categories);
    }


}
