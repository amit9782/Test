﻿using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BuyHQ.Core.Util
{
    public static class CategoryTreeHelper
    {
        public static string BuildBreadcrumb(this Category cat, ICategoryRepository repository, string seperator = " > ")
        {
            IList<string> names = new List<string>();

            Category category = cat;
            names.Add(cat.Name);
            while (category.ParentCategoryId != Guid.Empty)
            {
                category = repository.FindOne(x => x.Id == category.ParentCategoryId);
                if (category == null)
                    break;

                names.Add(category.Name);
            }
            var rev = names.Reverse(); // reverse it so the parent is at the top
            return String.Join(seperator, rev); ;
        }

        public static string BuildBreadcrumb(this SupplierCategory cat, ISupplierCategoryRepository repository, string seperator = " > ")
        {
            IList<string> names = new List<string>();

            SupplierCategory category = cat;
            names.Add(cat.Name);
            while (category.ParentCategoryId != Guid.Empty)
            {
                if (category == null)
                    break;

                category = repository.FindOne(x => x.Id == category.ParentCategoryId);
                names.Add(category.Name);
            }
            var rev = names.Reverse(); // reverse it so the parent is at the top
            return String.Join(seperator, rev); ;
        }
    }
}
