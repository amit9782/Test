﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AutoMapper;
using BornsToCode.Common.Data;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using BuyHQ.Data.MongoDb;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Cors.Internal;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;

namespace BuyHQ.API.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            

            // Add Cors
            services.AddCors(o => o.AddPolicy("BuyHQCORSPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));

            services.AddAutoMapper();
            services.AddMvc();

            services.Configure<MvcOptions>(options =>
            {
                options.Filters.Add(new CorsAuthorizationFilterFactory("BuyHQCORSPolicy"));
            });

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "BuyHQ API", Version = "v1" });
            });

            string databaseName = "buyhq";
            string connectionString = "mongodb://buyhq-user:SOh773TYu0bYhx8yJH6pJtQmruIlnsPxmt1oOfL@149.28.166.130:27017/buyhq";
            services.AddScoped<ICategoryRepository, CategoryRepository>(r => new CategoryRepository(connectionString, databaseName));
            services.AddScoped<ISupplierCategoryRepository, SupplierCategoryRepository>(r => new SupplierCategoryRepository(connectionString, databaseName));
            services.AddScoped<IProductRepository, ProductRepository>(r => new ProductRepository(connectionString, databaseName));
            services.AddScoped<ISupplierRepository, SupplierRepository>(r => new SupplierRepository(connectionString, databaseName));
            services.AddScoped<IRepository<SupplierCategory>, SupplierCategoryRepository>(r => new SupplierCategoryRepository(connectionString, databaseName));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), 
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "BuyHQ API V1");

                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
               // c.IncludeXmlComments(xmlPath);
               // TODO: Fix this
            });

            app.UseMvc();
        }
    }
}
