﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BornsToCode.Common.Data;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BuyHQ.API.WebAPI.Controllers
{
    [Route("api/category")]
    public class CategoryController : Controller
    {
        ICategoryRepository categoryRepo;
        ISupplierCategoryRepository supplierCategoryRepo;

        public CategoryController(ICategoryRepository categoryRepository, ISupplierCategoryRepository supplierCategoryRepository)
        {
            categoryRepo = categoryRepository;
            supplierCategoryRepo = supplierCategoryRepository;
        }

        [HttpGet("")]
        [HttpGet("{page:int}/{perPage:int}")]
        public IActionResult Index(int page = 1,
            int perPage = 50)
        {
            var result = categoryRepo.GetAllAsPaged(page, perPage);
            return Ok(result);
        }

        [HttpGet("{id:guid}")]
        [Route("{id:guid}")]
        public IActionResult GetById(Guid id)
        {
            var category = categoryRepo.FindOne(x => x.Id == id);
            if (category != null)
                return Ok(category);

            return NotFound();
        }

        [HttpGet("search")]
        public IActionResult Search(string search, int page = 1, int perPage = 50){
            var result = categoryRepo.FindAsPaged(x=> x.Name.ToLower().Contains(search.ToLower()), page, perPage);
            return Ok(result); 
        }

        [HttpPost]
        public IActionResult Post([FromBody] Category model)
        {
            categoryRepo.Save(model);
            return Ok();
        }
    }
}