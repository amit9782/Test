﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BornsToCode.Common.Data;
using BuyHQ.API.WebAPI.ViewModels;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BuyHQ.API.WebAPI.Controllers
{
    [Route("api/[controller]")]
    public class SupplierController : Controller
    {
        ISupplierRepository supplierRepo;
        ISupplierCategoryRepository supplierCategoryRepo;

        public SupplierController(ISupplierRepository repository, ISupplierCategoryRepository supplierCatRepo)
        {
            supplierRepo = repository;
            supplierCategoryRepo = supplierCatRepo;
        }

        [HttpGet("")]
        [HttpGet("{page:int}/{perPage:int}")]
        public IActionResult Index(int page = 1,
            int perPage = 50)
        {
            var result = supplierRepo.GetAllAsPaged(page, perPage);
            return Ok(result);
        }

        [HttpGet("{id:guid}")]
        [Route("{id:guid}")]
        public IActionResult GetById(Guid id)
        {
            var category = supplierRepo.FindOne(x => x.Id == id);
            if (category != null)
                return Ok(category);

            return NotFound();
        }

        [HttpGet("search")]
        public IActionResult Search(string search, int page = 1, int perPage = 50)
        {
            var result = supplierRepo.FindAsPaged(x => x.Name.ToLower().Contains(search.ToLower()), page, perPage);
            return Ok(result);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Supplier model)
        {
            supplierRepo.Save(model);
            return Ok();
        }

        [HttpGet("warehouse/{id:guid}")]
        public IActionResult Warehouse(Guid id){
            var warehouse = supplierRepo.Query().Where(x => x.Warehouses.Any(w => w.Id == id))
                                        .Select(x=> x.Warehouses)
                                        .FirstOrDefault();
            if(warehouse !=null){
                return Ok(warehouse);
            }
            return NotFound();
        }

        [HttpPost("warehouse")]
        public IActionResult Warehouse([FromBody]Warehouse model, [FromQuery]Guid supplierId)
        {
            var warehouse = supplierRepo.SaveWarehouse( supplierId, model);
            if (warehouse != null)
            {
                return Ok(warehouse);
            }
            return NotFound();
        }

        [HttpDelete("warehouse/{warehouseId:guid}")]
        public IActionResult Warehouse(Guid warehouseId, [FromQuery]Guid supplierId)
        {
            var success = supplierRepo.DeleteWarehouse(supplierId, warehouseId);
            if (success)
                return Ok();

            return NotFound();
        }
    }
}