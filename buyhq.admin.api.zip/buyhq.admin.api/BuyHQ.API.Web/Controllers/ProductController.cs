﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using AutoMapper;
using BornsToCode.Common.Extensions;
using BuyHQ.Core.Domain;
using BuyHQ.Core.Models;
using BuyHQ.Core.Repository;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using BuyHQ.API.WebAPI.ViewModels;

namespace BuyHQ.API.WebAPI.Controllers
{
    [Route("api/product")]
    public class ProductController : Controller
    {
        private IProductRepository productRepo;
        private ICategoryRepository categoryRepo;

        private IHostingEnvironment hostingEnvironment;
        private readonly IMapper mapper;

        public ProductController(IProductRepository prodRepo, ICategoryRepository catRepo, IHostingEnvironment hostingEnvironment, IMapper mapper)
        {
            this.productRepo = prodRepo;
            this.categoryRepo = catRepo;

            this.hostingEnvironment = hostingEnvironment;
            this.mapper = mapper;
        }

        [HttpGet("")]
        [HttpGet("{page:int}/{perPage:int}")]
        public IActionResult Index(int page = 1,
            int perPage = 50)
        {
            var query = productRepo.Query();
            var result = query
                 .Select(p => new ProductViewModel()
                 {
                     Id = p.Id,
                     MPN = p.MPN,
                     Name = p.Name,
                     ProductImagePath = p.ProductImagePath,
                     RRP = p.RRP,
                     SellPriceInc = p.SellPriceInc,
                     ShortDescription = p.ShortDescription,
                     SKU = p.SKU,
                     SpecialBuyEndDate = p.SpecialBuyEndDate,
                     SpecialBuyStartDate = p.SpecialBuyStartDate,
                     VendorName = p.VendorName,
                     BestBuyPriceEx = p.BestBuyPriceEx,
                     BestBuyPriceInc = p.BestBuyPriceInc,
                     BestBuySupplierId = p.BestBuySupplierId,
                     BestBuySupplierName = p.BestBuySupplierName,
                     SupplierStock = p.SupplierStock
                 })
                .ToPagedResult<ProductViewModel>(query.Count(), page, perPage);
            return Ok(result);
        }

        [HttpGet("search")]
        [HttpGet("search/{page:int}/{perPage:int}")]
        public IActionResult Search(
            [FromQuery]string name = "",
            [FromQuery]string vendor = "",
            [FromQuery]string sku = "",
            [FromQuery]string mpn = "",
            [FromQuery]int page = 1,
            [FromQuery]int perPage = 50)
        {
            var query = productRepo.Query();

            if (!string.IsNullOrEmpty(name))
            {
                query = query.Where(x => x.Name.ToLower().Contains(name));
            }
            if (!string.IsNullOrEmpty(vendor))
            {
                query = query.Where(x => x.VendorName.ToLower().Contains(vendor));
            }
            if (!string.IsNullOrEmpty(sku))
            {
                query = query.Where(x => x.SKU.ToLower().Contains(sku));
            }
            if (!string.IsNullOrEmpty(mpn))
            {
                query = query.Where(x => x.MPN.ToLower().Contains(mpn));
            }
            var result = query
                .Select(p => new ProductViewModel()
                {
                    Id = p.Id,
                    MPN = p.MPN,
                    Name = p.Name,
                    ProductImagePath = p.ProductImagePath,
                    RRP = p.RRP,
                    SellPriceInc = p.SellPriceInc,
                    ShortDescription = p.ShortDescription,
                    SKU = p.SKU,
                    SpecialBuyEndDate = p.SpecialBuyEndDate,
                    SpecialBuyStartDate = p.SpecialBuyStartDate,
                    VendorName = p.VendorName,
                    BestBuyPriceEx = p.BestBuyPriceEx,
                    BestBuyPriceInc = p.BestBuyPriceInc,
                    BestBuySupplierId = p.BestBuySupplierId,
                    BestBuySupplierName = p.BestBuySupplierName,
                    SupplierStock = p.SupplierStock
                })
                .ToPagedResult<ProductViewModel>(query.Count(), page, perPage);
            return Ok(result);
        }

        [HttpGet("vendors")]
        public IActionResult Vendors()
        {
            var vendors = productRepo.Query()
                                     .Select(x => x.VendorName)
                                     .Distinct()
                                     .ToList();

            return Ok(vendors);
        }

        [HttpGet("{id:guid}")]
        [Route("{id:guid}")]
        public IActionResult GetById(Guid id)
        {
            var product = productRepo.FindOne(x => x.Id == id);
            if (product != null)
                return Ok(product);

            return NotFound();
        }

        [HttpGet("detail/{id:guid}")]
        [Route("detail/{id:guid}")]
        public IActionResult GetProductDetails(Guid id)
        {
            var product = productRepo.FindOne(x => x.Id == id);
            if (product != null)
            {
                var dto = mapper.Map<Product, ProductDetailViewModel>(product);

                return Ok(dto);
            }

            return NotFound();
        }

        [HttpPost("detail/{id:guid}")]
        [Route("detail/{id:guid}")]
        public IActionResult SaveProductDetails(Guid id, [FromBody]ProductDetailViewModel model)
        {
            var product = productRepo.FindOne(x => x.Id == id);
            if (product != null)
            {
                var toSave = mapper.Map<ProductDetailViewModel, Product>(model);
                productRepo.Save(toSave);
                return Ok(toSave);
            }

            return NotFound();
        }

        [HttpGet("stock/{id:guid}")]
        [Route("stock/{id:guid}")]
        public IActionResult GetProductStock(Guid id)
        {
            var stock = productRepo.Query()
                .Where(x => x.Id == id)
                .Select(x=> x.SupplierStock);

            if (stock != null)
            {
                return Ok(stock);
            }

            return NotFound();
        }

        [HttpGet("category/{id:guid}")]
        [Route("category/{id:guid}")]
        public IActionResult GetProductCategories(Guid id)
        {
            var productCategories = productRepo.Query()
                .Where(x => x.Id == id)
                .Select(x=> x.Categories);

            if (productCategories != null)
            {
                return Ok(productCategories);
            }

            return NotFound();
        }

        [HttpPost("category/{id:guid}")]
        [Route("category/{id:guid}")]
        public IActionResult SaveProductCategories(Guid id, [FromBody] List<Guid> guids)
        {
            var product = productRepo.FindOne(x => x.Id == id);
            if (product != null)
            {
                var categories = categoryRepo
                    .FindManyById(guids)
                    .Select(x=> new ProductCategory(x.Id, x.Path))
                    .ToList();

                try
                {
                    productRepo.SaveCategoriesForProduct(id, categories);
                }
                catch(Exception e){
                    var ex = e;
                }
                return Ok();
            }

            return NotFound();
        }


        [HttpPost]
        public IActionResult Post([FromBody] Product model)
        {
            productRepo.Save(model);
            return Ok();
        }


        [HttpPost("assets/upload/{id:guid}"), DisableRequestSizeLimit]
        public ActionResult UploadFile(Guid id, bool isDefault = false)
        {
            var file = Request.Form.Files[0];
            string folderName = "Upload";
            string webRootPath = hostingEnvironment.WebRootPath;
            string newPath = Path.Combine(webRootPath, folderName);
            if (!Directory.Exists(newPath))
            {
                Directory.CreateDirectory(newPath);
            }
            if (file.Length > 0)
            {
                string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                string fullPath = Path.Combine(newPath, fileName);
                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                if (productRepo.AddImage(id, fileName, isDefault))
                    return Ok();
                else
                    return BadRequest("Error uploading image");
            }

            return Ok();
        }
    }
}