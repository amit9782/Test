﻿using System;
namespace BuyHQ.API.WebAPI.ViewModels
{
    public abstract class ViewModelBase
    {
        public ViewModelBase()
        {
        }

        public Guid Id { get; set; }
    }
}
