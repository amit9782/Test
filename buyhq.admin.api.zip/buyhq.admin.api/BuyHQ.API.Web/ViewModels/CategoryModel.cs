﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BuyHQ.API.WebAPI.ViewModels
{
    public class CategoryModel : ViewModelBase
    {
        public CategoryModel()
        {
        }
        public bool IsRoot { get; set; } = false;

        public Guid ParentCategoryId { get; set; }

        [Required]
        public string Name { get; set; }

        public string Description { get; set; }

        public string Breadcrumb { get; set; }

        public string SeoKeywords { get; set; }
        public string SeoTitle { get; set; }
        public string SeoDescription { get; set; }

        [Required]
        public string Slug { get; set; }
    }
}
