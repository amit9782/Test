﻿using System;

namespace BuyHQ.API.WebAPI.ViewModels
{
    public class ProductDetailViewModel : ViewModelBase
    {
        public string SeoKeywords { get; set; }

        public string SeoTitle { get; set; }

        public string SeoDescription { get; set; }

        public string Slug { get; set; }

        public bool IsActive { get; set; }

        public decimal BestBuyPriceEx { get; set; }
        public decimal BestBuyPriceInc { get; set; }

        public Guid BestBuySupplierId { get; set; }
        public string BestBuySupplierName { get; set; }

        public string Name { get; set; }

        public string SKU { get; set; }

        public string MSN { get; set; }

        public string MPN { get; set; }

        public string UPC { get; set; }

        public string EAN { get; set; }

        public string VendorName { get; set; }

        public string ShortDescription { get; set; }

        public string FullDescription { get; set; }

        public decimal RRP { get; set; }

        public decimal SellPriceInc { get; set; }


        public DateTime? SpecialBuyStartDate { get; set; }

        public DateTime? SpecialBuyEndDate { get; set; }

        public decimal SpecialPrice { get; set; }

        public string ProductImagePath { get; set; }

        public string WarrantyDuration { get; set; }

        public string WarrantyInfo { get; set; }

        #region Measurements

        public decimal Height { get; set; }
        public decimal Length { get; set; }
        public decimal Width { get; set; }

        public decimal Cubic { get; set; }

        public decimal Weight { get; set; }

        #endregion

       

    }
}
