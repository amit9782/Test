﻿using BuyHQ.Core.Domain;
using System;
using System.Collections.Generic;

namespace BuyHQ.API.WebAPI.ViewModels
{
    public class SupplierCategoryModel : CategoryModel
    {
        public SupplierCategoryModel()
        {
        }

        public Guid SupplierId { get; set; }
        public Guid SupplierCategoryId { get; set; }

        public List<Guid> MapsToCategories { get; set; } = new List<Guid>();
            
    }

    public class SupplierModel : ViewModelBase
    {
        public SupplierModel()
        {
        }

        public string Name { get; set; }

        public string Website { get; set; }

        public string SalesEmail { get; set; }

        public string OrderEmail { get; set; }

        public string AccountEmail { get; set; }

        public UnitOfMeasure WeightUOM { get; set; }
        public UnitOfMeasure DimensionUOM { get; set; }
        public UnitOfMeasure CubicUOM { get; set; }

        /// <summary>
        /// Our account name or number, used for ordering
        /// </summary>
        public string AccountNumber { get; set; }

        public Address Address { get; set; }

        /// <summary>
        /// Number of days to pay 
        /// 0 = Cash on Delivery / Order
        /// </summary>
        public int PaymentTerms { get; set; } = 0;

        public List<Warehouse> Warehouses { get; set; } = new List<Warehouse>();

        public List<SupplierStock> Products { get; set; } = new List<SupplierStock>();

    }
}
